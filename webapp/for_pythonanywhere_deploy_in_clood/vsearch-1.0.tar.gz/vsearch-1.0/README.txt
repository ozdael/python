This is a textual description of the distribution file setup.py, which can be empty.
